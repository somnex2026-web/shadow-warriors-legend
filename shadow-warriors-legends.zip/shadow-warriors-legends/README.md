# SHADOW WARRIORS: LEGENDS

A mobile-first, original 3D browser fighting RPG built with Three.js. It uses procedural, articulated 3D fighters and arena geometry, so no model downloads or paid services are required.

## Play locally on Android

1. Download and extract `shadow-warriors-legends.zip` on your Android phone.
2. Upload the extracted folder to a free static host (GitHub Pages is recommended), or use a browser IDE such as StackBlitz.
3. Open the deployed `index.html` URL in Chrome. Three.js is imported from jsDelivr, so the first launch needs internet access.
4. Rotate to landscape for the best control layout. Use the left virtual stick and the action buttons on the right.
5. Desktop testing: A/D or arrow keys move; J punch; K kick; L heavy; U special; I guard; Space jump; Escape pause.

## Free GitHub Pages deployment

1. Sign in to GitHub in Chrome and create a public repository named `shadow-warriors-legends`.
2. Upload the files and folders from this project (keep `index.html`, `style.css`, and `src/` at repository root).
3. Open repository **Settings → Pages**.
4. Under Build and deployment choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for the Pages URL and open it in Chrome on Android.

## Included gameplay

- Real-time Three.js WebGL scene, 3D arena, lighting, fog, shadows, camera framing.
- Fifteen procedural 3D fighters with different palettes, stats, and elemental identities.
- Punch, kick, heavy, guard, dodge, jump and elemental special attack; range-based hit checks, damage, defense, stun, knockback, critical hits, combo counter, energy.
- Enemy AI, training, battle, story, survival, boss and tournament entry modes.
- Ten story chapter progression steps and eight arena palettes.
- Weapon forge and eight weapon categories; fighter unlocks, XP, levels, coins, skill upgrades, profile and local save.
- Touch and keyboard controls; sound toggle; graphics quality and 30/60 FPS target setting.

## Honest scope notes

This is a playable vertical-slice game, not a finished commercial AAA production. Character geometry and animation are procedural rather than imported artist-authored rigs. Story progression currently advances one encounter per chapter, with the chapter list and kingdom/arena themes represented in the game data. The weapon forge currently handles unlock/equip and upgrade progression; weapon meshes use a shared procedural blade silhouette. Rust/WASM is included as an optional example module only; the JavaScript game does not require it. The browser must support WebGL and ES modules.

## Performance and troubleshooting

- The game caps device pixel ratio to reduce GPU load and disables antialiasing on touch devices.
- If the page is slow, select LOW graphics, close other browser tabs, and use Chrome in landscape.
- If a blank screen appears, check the internet connection (Three.js CDN), then reload.
- Save data is stored in localStorage for this first playable release. Clearing browser site data will erase it.
- Do not expect 60 FPS on every Android device; choose the 30 FPS target for lower-end hardware.

## Project layout

```text
shadow-warriors-legends/
  index.html
  style.css
  README.md
  package.json
  src/main.js
  rust-core/Cargo.toml
  rust-core/src/lib.rs
```
