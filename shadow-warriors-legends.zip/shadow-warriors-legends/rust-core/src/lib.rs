use wasm_bindgen::prelude::*;

// Optional deterministic combat math. The browser game remains fully playable
// without compiling or loading this module.
#[wasm_bindgen]
pub fn calculate_damage(power: f32, defense: f32, multiplier: f32, blocked: bool) -> f32 {
    let reduction = 100.0 / (100.0 + defense.max(0.0) * 4.0);
    let guard = if blocked { 0.22 } else { 1.0 };
    (power.max(0.0) * multiplier.max(0.0) * reduction * guard).max(1.0)
}

#[wasm_bindgen]
pub fn clamp_energy(current: f32, delta: f32) -> f32 {
    (current + delta).clamp(0.0, 100.0)
}
